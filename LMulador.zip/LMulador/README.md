# LMulador

Cross-platform Electron app embedding:
- Lightweight Linux VM (QEMU/Docker)
- xterm.js-based terminal with plugin support
- React & Tailwind UI shell
- CLI extension modules
- Wine/Proton game emulation
