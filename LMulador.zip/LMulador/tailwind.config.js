module.exports = {
  content: ['./renderer/**/*.{js,jsx}', './public/index.html'],
  theme: { extend: {} },
  plugins: [],
};
