module.exports = {
  name: 'hello',
  description: 'Print hello from LMulador CLI',
  run: () => console.log('Hello from LMulador CLI')
};
