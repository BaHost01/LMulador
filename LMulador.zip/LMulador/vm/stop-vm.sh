#!/usr/bin/env bash
set -euo pipefail
pkill qemu-system-x86_64 && echo "VM Stopped"
